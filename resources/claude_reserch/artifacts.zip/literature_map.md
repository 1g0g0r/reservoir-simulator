# Recent literature map: wax & asphaltene deposition during non-isothermal oil filtration

*Numerical modeling of paraffin and asphaltene deposition in porous media / reservoir flow — a map of the 2015–2026 literature.*

## How this map was built

The corpus was assembled programmatically from Crossref (journal articles, 2015 onward) across twelve query phrases spanning the subfield — wax/paraffin and asphaltene deposition, precipitation and flocculation, in reservoirs, porous media, wellbores and pipelines, plus the thermodynamic, kinetic, non-isothermal and numerical angles. Records were scored for topical relevance on title + abstract, and each surviving record was enriched with abstracts, subject concepts and citation counts from OpenAlex. After deduplication and relevance filtering the working corpus is **809 journal articles**. Abstracts were recoverable for 533 of them; theme tags below rest on title + abstract + OpenAlex concepts, so they undercount slightly where no abstract exists.

Two caveats worth keeping in mind: (1) Crossref bibliographic search is recall-oriented, so the corpus is a *representative sample* of the subfield rather than a complete census; (2) the 2026 count (46 papers) is a partial year and is excluded from trend statements.

## 1. Output is steady, not exploding

![Publication trend by species]({{artifact:e1cb2728-a29b-4e13-9c97-fa50717036ad}})

The subfield produces roughly **70–85 papers per year** and has done so consistently since about 2018 — a mature, stable field rather than a hot emerging one. Wax/paraffin (367 papers) and asphaltene (360) work are almost evenly split, with a small but growing set (79) treating both species together — relevant to you, since real reservoir deposits (ARPD — asphaltene-resin-paraffin deposits) are mixed.

## 2. What the field works on

![Theme prevalence and shift over time]({{artifact:7ecf4464-a300-4cc7-b0c2-f6039ff6790d}})

Experimental characterization dominates (present in ~48% of papers), followed by pipeline/flow-assurance framing and porous-media/formation-damage framing. The right panel compares each theme's share of papers in 2015–2019 vs 2021–2025:

- **Growing fastest:** pipeline / flow assurance (+9.2 pts), CFD / numerical simulation (+3.7), deposition kinetics & transport (+3.6), chemical inhibitors (+3.0), and machine-learning / data-driven models (+2.3, from a very low base).
- **Holding steady or easing:** porous-media / formation-damage framing (−2.4), EoS/SAFT thermodynamic modeling (−1.7), and — notably for you — the explicitly **non-isothermal / heat-transfer** framing is flat at ~20%.

The takeaway: the *numerical* end of the field is expanding (CFD, kinetics, ML), but most of that growth is happening in **pipeline** geometry, not reservoir/porous-media geometry. Your specific combination — non-isothermal filtration *in the porous medium* — remains comparatively thinly populated.

## 3. Where the work publishes

![Top venues]({{artifact:79252467-c045-4bfe-9916-eca5283dcb87}})

*Energy & Fuels* (75) and *Fuel* (65) lead, followed by *Journal of Petroleum Science and Engineering* (52) and its successor *Geoenergy Science and Engineering* (17), *Petroleum Science and Technology* (48), and *SPE Journal* (18). For modeling-heavy work specifically, *Fuel*, *JPSE/Geoenergy Science and Engineering*, *SPE Journal*, and *Fluid Phase Equilibria* (thermodynamics) are the natural targets. *Journal of Petroleum Exploration and Production Technology* and *Processes* are the more accessible open-access options where the non-isothermal-flow modeling papers closest to your niche have appeared.

## 4. Landmark papers (most-cited, whole subfield)

These are the field's high-citation anchors — worth knowing even where they sit slightly off your exact problem:

| Cites | Year | First author | Title (short) |
|------:|------|--------------|---------------|
| 268 | 2019 | S. Alimohammadi | A comprehensive review of asphaltene deposition in petroleum reservoirs |
| 164 | 2021 | I. Mohammed | Asphaltene precipitation and deposition: a critical review |
| 164 | 2015 | J. Liu | Molecular dynamics simulation of asphaltene self-aggregation |
| 158 | 2017 | K. Gharbi | Removal and prevention of asphaltene deposition during oil production |
| 136 | 2017 | Y. Chi | Effect of the flow field on wax deposition |

(The two most-cited *paraffin* entries — Rehman 2018, Arıcı 2017 — are on phase-change / thermal-energy-storage uses of paraffin wax, not petroleum deposition; they surface on keyword overlap and are not central to your problem.) Full ranked list in `landmark_papers_overall.csv`.

## 5. Closest to your niche — non-isothermal filtration + deposition modeling in porous media

Filtering the corpus to the intersection of **porous-media/formation-damage + a modeling theme (CFD, kinetics, or thermodynamics)** yields 94 papers; requiring the **non-isothermal / heat-transfer** framing on top of that narrows it to a small, tightly relevant cluster. The recent (2023+) papers nearest your exact problem:

| Year | First author | Title (short) | DOI |
|------|--------------|---------------|-----|
| 2024 | U. Zhapbasbayev | Numerical modeling of non-isothermal laminar flow and heat transfer (waxy oil) | 10.3390/en17092080 |
| 2025 | D. Bossinov | Numerical simulation of non-isothermal laminar oil flow in a pipe | 10.4028/p-zjxnt3 |
| 2026 | A. Togasheva | Risk assessment of asphaltene-resin-paraffin deposition during reservoir development | 10.3390/eng7040184 |
| 2026 | V. Maksimovich | Effect of sedimentation of asphaltene-resin-paraffin components | 10.31084/2619-0087/2026-1-9 |
| 2025 | S. Chen | Numerical modeling of asphaltene deposition in CO₂-flooded porous media | 10.1063/5.0251349 |
| 2024 | S. Feng | Numerical simulation of asphaltene precipitation and deposition | 10.32604/fdmp.2023.041825 |
| 2018 | I. Struchkov | Laboratory investigation of asphaltene-induced formation damage | 10.1007/s13202-018-0539-z |

Notable observations for you:

- There is a **Kazakh / Russian school** (Zhapbasbayev, Bossinov, Togasheva, Maksimovich, Struchkov, Voloshin) working directly on non-isothermal flow and ARPD deposition — the closest match to your methodological framing. Worth tracking as your immediate peer group / potential citation and comparison base.
- The fastest-moving *reservoir-scale* numerical topic right now is **asphaltene deposition during CO₂ / gas injection in porous media** (Chen 2025/2026, Shakibasefat 2026, Tazikeh 2025, Khurshid). If you want your non-isothermal filtration model to stay current, coupling it to gas-injection / EOR scenarios is where the reservoir-modeling frontier is heading.
- Genuinely coupled **non-isothermal + porous-media + deposition** modeling remains sparse (only a handful of papers hit all three tags simultaneously) — this is the gap your thesis sits in, which is good news for novelty.

Full lists: `landmark_papers_niche.csv` (top 20 by niche relevance) and `recent_niche_papers.csv` (2023+).

## 6. Suggested directions this map points to

1. **Position against the Zhapbasbayev/Struchkov school** — they share your non-isothermal-filtration framing; comparing your deposition kinetics or porosity-permeability coupling to theirs is the most direct novelty argument.
2. **Consider a gas-injection / CO₂ coupling** — the reservoir-scale modeling frontier is moving there, and non-isothermal effects on asphaltene onset under CO₂ are under-modeled.
3. **The ML/data-driven theme is small but growing** — a hybrid physics + surrogate model for deposition rate could be a distinctive contribution given how few papers combine the two.
4. **Target venues:** *Fuel*, *Geoenergy Science and Engineering*, *SPE Journal* for the core modeling paper; *Journal of Petroleum Exploration and Production Technology* / *Processes* for faster/OA turnaround.

---
*Corpus and all derived tables are saved as artifacts (`corpus.csv` — 809 records with year, venue, authors, citations, theme tags, and niche-relevance score). Citation counts are the max of Crossref and OpenAlex as of the query date and will drift upward over time.*
