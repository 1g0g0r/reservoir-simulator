# Methods and approaches in wax/asphaltene deposition modeling — a deeper review

*Companion to `literature_map.md`. Corpus widened from 809 to **1043 journal articles** (2015–2026) by adding twelve methods-focused Crossref queries (PC-SAFT, pore-network, lattice Boltzmann, population balance, colloidal instability index, ML, CFD, history matching, multi-solid model). Every record is now tagged along four independent axes — thermodynamic/molecular framework, deposition mechanism, numerical technique, experimental method — using a keyword taxonomy over title + abstract + OpenAlex concepts. Tags are not mutually exclusive; a paper can carry several.*

## Overview: four modeling layers

Reservoir/pipeline organic-deposition modeling decomposes into four largely independent modeling choices that get combined:

1. **Thermodynamic/phase framework** — decides *whether and how much* solid forms.
2. **Deposition mechanism** — decides *how* the solid reaches and sticks to a surface or pore wall once formed.
3. **Transport/numerical method** — the PDE solver or simulator coupling flow, heat, and the above.
4. **Experimental method** — how the model's parameters get measured or the predictions validated.

### 1. Thermodynamic / phase-behavior frameworks

![Thermodynamic frameworks by species]({{artifact:8d4cd3c5-0dfb-40b7-8b21-e624b11dbd2c}})

For **wax/paraffin**, the dominant approach remains the **multi-solid / solid-solution model** (11 tagged papers) — treating the precipitating wax as a series of solid solutions of n-alkane pseudo-components in equilibrium with the liquid, parameterized from a carbon-number distribution (usually via gas chromatography). **PC-SAFT** (10 papers) is increasingly used to close the liquid-phase fugacities more rigorously than the older regular-solution/Flory-Huggins treatments (3 and 8 papers respectively), especially when asphaltenes and resins are present alongside the wax and interact with it.

For **asphaltenes**, the field has largely moved to **PC-SAFT / SAFT-type equations of state** (31 papers) coupled with a **colloidal/micellization picture** (21 papers) — treating asphaltenes as nanoaggregates whose stability is governed by a solvation-shell balance (the modified Yen-Mullins picture), rather than as a simple solubility-parameter precipitant. Molecular dynamics and DFT studies (37 papers, more than any other single framework) are used mainly to parameterize aggregation/adsorption energetics that feed the continuum models rather than to simulate deposition directly at reservoir scale.

**Implication for you:** for coupled wax+asphaltene (ARPD) systems, a PC-SAFT-based EoS is now the more defensible choice than pairing a multi-solid wax model with a separate colloidal asphaltene model, because it lets both solid phases be predicted from one consistent fugacity framework — though very few papers (≈12 in this corpus) actually do this coupling; most treat the two species with separate, non-interacting sub-models.

### 2. Deposition mechanisms — a clean species split

![Deposition mechanisms by species]({{artifact:e4a03573-28aa-4a0d-bf48-781909100185}})

The mechanism vocabulary used for wax and for asphaltenes is almost disjoint, which reflects two different physical pictures the field has settled into:

- **Wax deposition** is framed around the classical Burger–Perkins–Striegler-type picture: **molecular diffusion** down the radial concentration gradient (7.6% of wax papers) driven by the temperature gradient across the wall, compounded by **shear dispersion** (4.7%) and subsequent **aging/gelation** of the deposit (11.0% — the largest single mechanism tag for wax) as trapped liquid oil diffuses out and the wax fraction of the gel rises with time. This is fundamentally a **boundary-layer / near-wall problem**, driven by temperature difference between the bulk fluid and the wall (or pore surface).
- **Asphaltene deposition** is framed around a **colloidal aggregation and surface-capture** picture: **aggregation/flocculation via population-balance treatment** (24.8% — by far the dominant mechanism tag for asphaltene), followed by **surface deposition/adsorption** (16.5%) onto pore walls, and **pore plugging/straining** (6.3%) once aggregates exceed the pore-throat size. This is fundamentally a **bulk-precipitation-then-capture problem**, driven by pressure drop (below the asphaltene onset pressure) more than by temperature per se — though CO₂/gas-injection studies (Chen 2025/2026, Shakibasefat 2026, Feng 2024) show composition and temperature both shift the onset envelope.

For your non-isothermal filtration problem with *both* species present, this split matters mechanically: wax deposition needs a temperature field and a diffusive/shear deposition-rate closure at the pore or capillary wall; asphaltene deposition needs a phase-split (precipitated fraction) tracked through the pressure/temperature/composition path and a capture-and-plugging closure referenced to local pore-throat size distribution. Very few papers couple both closures self-consistently in a single porous-medium simulation.

### 3. Numerical / simulation techniques

![Numerical method adoption over time]({{artifact:c4a78ac1-473d-42d0-b182-7b89a78ab952}})

Method adoption by period (share of that period's papers):

| Method | 2015–17 | 2018–20 | 2021–23 | 2024–26 |
|---|---:|---:|---:|---:|
| ML / data-driven surrogate | 2.4% | 1.7% | 4.4% | 5.6% |
| Molecular/microscale simulation (MD, Monte Carlo) | 1.9% | 2.0% | 5.1% | 4.1% |
| CFD (finite volume/element, ANSYS/COMSOL) | 1.5% | 2.4% | 1.5% | 3.8% |
| Reservoir/pipe-flow simulator (in-house or commercial) | 0.5% | 0.3% | 1.1% | 1.1% |
| Analytical/semi-analytical | 0.5% | 0.7% | 0.4% | 1.1% |
| Lattice Boltzmann | 0.5% | 0.3% | 0.4% | 0.4% |
| Pore-network model | 1.0% | 0.0% | 0.0% | 0.4% |

Three observations:

- **CFD (ANSYS Fluent/COMSOL) is the field's default numerical workhorse** for pipeline-scale problems and is growing (1.5% → 3.8%). Examples in this corpus: 3-D finite-element heat-transfer models of the wax layer on buried pipelines (Xie et al. 2022), and coupled VOF + discrete-phase-model treatments of asphaltene deposition during CO₂ flooding (Chen 2025).
- **Machine learning is the fastest-growing category** (2.4% → 5.6%) but is used almost entirely for **prediction/correlation** (deposition rate, WAT, permeability-reduction correlations) rather than for solving the governing transport equations — i.e., as a surrogate for expensive lab correlations, not as a replacement for mechanistic PDE solving.
- **Pore-scale mechanistic methods — pore-network models, lattice Boltzmann, and true finite-difference reservoir solvers — are rare and not growing** (each under 0.5% of papers per period, and pore-network modeling has essentially disappeared since Nikooey's 2015 dynamic pore-scale network model). This is the clearest gap: almost nobody in the last decade has built a pore-scale, mechanistic, non-isothermal deposition model validated against core-flood or micro-CT data. Lin et al. (2016, microfluidic visualization of asphaltene deposition) and Lin (2021, micro-CT pore-clogging imaging) supply the experimental pore-scale data that such a model would need to be validated against, but the modeling side hasn't caught up.

### 4. Experimental methods (for parameterization and validation)

The corpus's experimental backbone: **microscopy/spectroscopy characterization** (150 papers — SARA fractionation, FTIR, cross-polarized microscopy), **WAT/onset-point measurement** (140), **rheology/viscometry** (71), **cold-finger/flow-loop tests** (57, mainly for wax deposition rate under controlled wall-cooling), and **core flooding** (20, mainly for asphaltene-induced permeability impairment — e.g. Kordestany 2018, Mohammadzadeh 2018, Su 2021's integrated aggregation+deposition simulator calibrated against core-flood permeability decline).

## What this means for a non-isothermal-filtration + ARPD numerical model

Based on the taxonomy and the closest papers found (Zhapbasbayev 2024, Bossinov 2025, Togasheva 2026 — the school working on exactly your combination):

1. **The state of the art for non-isothermal pipe/reservoir flow of waxy oil** treats the oil as a temperature-dependent Bingham/Shvedov-Bingham viscoplastic fluid once wax crystallizes, solved by finite-volume methods (SIMPLE-type pressure-velocity coupling) — Zhapbasbayev's group reports the emergence of a near-wall "stagnation zone" of viscoplastic fluid as the flow cools. This gives you a template rheological closure and solution method, but it is developed for pipe geometry, not porous-medium (Darcy-scale) flow.
2. **Asphaltene deposition modeling at reservoir scale under thermal/compositional change** (Chen 2025/2026, Shakibasefat 2026, Feng 2024) increasingly uses coupled multiphase-flow + discrete/population-balance deposition models validated against core-scale data, driven mainly by CO₂/gas-injection use cases — a template for the compositional-and-pressure side of your problem, but these largely treat temperature as a fixed reservoir condition, not a spatially-varying field being solved for simultaneously with deposition.
3. **The genuine gap** — confirmed by both the theme-shift data in the companion map and this deeper methods pass — is a model that (a) solves the **coupled non-isothermal Darcy/Forchheimer flow + heat transfer field** in the porous medium, (b) tracks **wax and asphaltene phase splits together** from one thermodynamic framework (PC-SAFT is the natural choice), and (c) applies **species-appropriate deposition-rate closures** (diffusion/aging for wax, population-balance/pore-throat-capture for asphaltenes) with a resulting **porosity–permeability feedback**. No paper in this 1043-record corpus does all four simultaneously; the closest partial matches split roughly 60/40 between the Kazakh/Russian non-isothermal-flow school (thermal side strong, deposition/permeability-feedback side weak) and the CO₂-EOR asphaltene-deposition literature (deposition/permeability-feedback side strong, thermal side weak or absent).

## Data

- `corpus_v2.csv` — full 1043-record corpus with all four taxonomy columns (`thermo_tags`, `mechanism_tags`, `numerical_tags`, `experimental_tags`), species, theme flags, and niche-relevance score.
- Figures: thermodynamic-framework split (`figC_thermo.png`), mechanism split (`figB_mechanisms.png`), numerical-method adoption over time (`figA_numerical_trend.png`).

*As before: keyword-based tagging is a coarse instrument — it flags a paper's vocabulary, not a verified reading of its method. Treat percentages as directional (which techniques are common vs. rare, growing vs. flat), not as a precise census, and read full text before citing a specific paper's exact governing equations.*
